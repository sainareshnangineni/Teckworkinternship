import java.util.*;
class Agecalculator
{
     public static void main(String[] args)
    {
      int p_year,p_month,p_day;
      int b_year,b_month,b_day;
      Scanner s = new Scanner(System.in);
      System.out.println("PersonName:");
      String PersonName = s.next();
    
      System.out.println("Enter the  p_year,p_month,p_day: ");
      p_year = s.nextInt();
      p_month = s.nextInt();
      if(p_month>13)
      {
        System.out.println("please enter the correct month(below 13):");
      }
      p_month = s.nextInt();
      p_day = s.nextInt();
      System.out.println("Enter the b_year,b_month,b_day : ");
      b_year = s.nextInt();
      b_month = s.nextInt();
      b_day = s.nextInt();
      if(p_year>b_year && p_month<=12 && p_day<=31);
      {
        int p_age = p_year-b_year;
        System.out.println(PersonName +"   p_age is"+"("+p_year+"-"+p_month+"-"+p_day +")" +p_age);

        System.out.println(PersonName +"   b_age is"+"("+p_year+"-"+p_month+"-"+p_day +")");
      if(p_age<18)
      {
        System.out.println(PersonName +"  is minor");
      }
        else
      {
        System.out.println(PersonName +"  Adult");
      }
      
      }
     }
  }
    
  