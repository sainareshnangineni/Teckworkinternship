import java.util.*;
class EmployeeSalary
  {
    public static void main(String[] args)
    {
     double salary;
     double house,trans,ta,gross,net;
      Scanner s=new Scanner(System.in);
      System.out.println("Enter the basic salary:");
      salary=s.nextDouble();
      house = s.nextDouble();
      trans= s.nextDouble();
      ta = s.nextDouble();
      house= .15*salary;
      trans= .20*salary;
      ta=.05*salary;
      gross=(house+trans+salary);
      net = gross-ta;
      System.out.println("The Gross pay is: "+gross);
      System.out.println("The net pay is:"+net);
    }
  }