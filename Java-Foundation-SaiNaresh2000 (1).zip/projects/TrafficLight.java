import java.util.*;
class TrafficLight;
{
  public static void main(String[] args)
    {
    
    }
}