import java.util.Scanner;
class TemperatureFC
  {
    public static void main(String areg[])
    {
    double f,c;
      Scanner s = new Scanneer(System.in);
      System.out.println("Choose type of conversion \n 1.Fahrenheit to clesius. \n 2.Celcius to Fauhrenhiet.");
    int ch = s.nextInt();
      switch(ch)
        {

          case 1:
            System.out.println("Enter FauhrenHeit tepmprature:");
            f = s.nextDouble();
            c = (f-32)*5/9;
          System.out.println("Celsius temprature is = "+c);
           break;
          case 2:
            System.out.println("Enter Celsisus temprature: ");
            c = s.nextDouble();
            f = ((9*c)/5)+32;
            System.out.println("Fahurenheit temprature is = "+f);
            break;
          default:
            System.out.println("please choose valid choice")
        }
    }
  }