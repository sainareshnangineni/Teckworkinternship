import java.util.Scanner;
class StudentGrade{
  public static void main(String[] args)
  {
  int count,i;
  float totalmarks=0,percentage,average;
  Scanner s = new Scanner(System.in);
  System.out.println("Enter the no of subject:");
 count = s.nextInt();
 System.out.println("Enter the " + count + " subject marks");
  for(i=0;i<count;i++)
  {
     totalmarks +=s.nextInt();
    
  }
    System.out.println("totalmarks:"+totalmarks);
    percentage=(totalmarks/(count*100))*100;
    switch((int)percentage/10)
      {
        case 1:
           System.out.println("Grade : A+");
          break;
        case 2:
           System.out.println("Grade : A");
          break;
        case 3:
          System.out.println("Grade : B");
          break;
        case 4:
          System.out.println("Grade : C");
          break;
        case 5:
          System.out.println("Grade : D");
        default:
          System.out.println("Grade: Fail");
          break;
          
      }
 }
}