import java.util.*;
class calculator
  {
    public static void main(String[] args)
    {
      char operator;
      int n1,n2,m,i,n;
      Scanner s = new Scanner(System.in);
      System.out.println("Enter the operator: ");
      operator = s.nextLine().charAt(0);
      System.out.println("Enter the 1st number:");
      n1 = s.nextInt();
      System.out.println("Enter the 2nd number:");
      n2 = s.nextInt();
      i = s.nextInt();
      n = s.nextInt();
     
      switch(operator)
        {
          case '+':
            m = n1+n2;
            System.out.println(n1+"+"+n2+"="+m);
            break;
          case '-':
            m = n1-n2;
            System.out.println(m);
            break;
          case '*':
            m = n1*n2;
          System.out.println(n1+"*"+n2+"="+m);
            break;
          case '%':
            m = n1%n2;
            System.out.println(m);
            break;
          case '/':
            m  = n1/n2;
            System.out.println(n1+"/"+n2+"="+m);
            break;
          case '^':
            m = n1^n2;
            System.out.println(m);
            break;
          default:
            System.out.println("invalid operator!");
            System.out.println("do you want to perform the task for many times:");
          
            
            }
    }
  }