import java.util.*;
public class Word
  {
    public static void main(String[] args)
    {
      
    int word;
    Scanner C = new Scanner(System.in);
    word = C.nextInt();
    switch(word){
      case 'a':
          System.out.println("Vowel is a");
          break;
      case 'e':
          System.out.println("Vowel is e");
          break;
      case 'i':
          System.out.println("Vowel is i");
          break;
      case 'o':
          System.out.println("Vowel is o");
          break;
      case 'u':
          System.out.println("Vowel is u");
          break;
        default:
          System.out.println("printing the  word is consonent");
          break;
    }
  }
  }