import java.util.Scanner;
 public class Marks
 {
   public static void main(String[] args)
 {
   int phy,che,math,bio,comp;
    
  Scanner s = new Scanner(System.in);
   phy = s.nextInt();
   che = s.nextInt();
   math = s.nextInt();
   bio = s.nextInt();
   comp = s.nextInt();
   float sum=((phy+che+math+bio+comp));
   float per = (sum/500)*100;
   
   if(per>=90)
     System.out.println("Grade :A");
   else if(per>=80 && per<90)
   System.out.println("Grade :B ");
   else if(per>=70 && per<80)
   System.out.println("Grade: C ");
   else if(per>=50 && per<60)
   System.out.println("Grade: D ");
   else if(per<40)
   System.out.println("Grade: disqualify ");
   else
   System.out.println("nothing");
    }
 }
