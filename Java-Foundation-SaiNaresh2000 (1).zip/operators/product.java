import java.util.*;
public class product
 {
   public static void main(String args[])

    {

      string productname;

      double mrp,sellingprice;

      Scanner S=new Scanner(System.in);

      productname=S.next().charAt(0);

      mrp=S.nextDouble();

      sellingprice=S.nextDouble();

      sellingprice=mrp*10/100;

      System.out.print("sellingprice is"+selling_price)

    }
  }

