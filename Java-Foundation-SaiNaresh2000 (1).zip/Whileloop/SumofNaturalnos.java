import java.util.*;
class SumofNaturalnos
  {
    public static void main(String args[])
    {
      int i=1,num=10,sum=0;
      while(i<=num)
        {
          sum=sum+i;
          System.out.println("sum= "+sum);
          i++;
        }
      
    }
  }