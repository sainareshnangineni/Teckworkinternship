import java.util.*;
class NaturalnosReverse
 {
  public static void main(String args[])
  {
  Scanner s=new Scanner(System.in);
  System.out.println("Enter the n:");
  int n = s.nextInt();
   while(n!=0);
    {
      System.out.println(n);
     
    }
    n--;
  }
}