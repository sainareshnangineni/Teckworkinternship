import java.util.*;
public class Max2nos
{
public static void main(String args[])
{
int x,y,max;
Scanner s= new Scanner(System.in);
System.out.println("Enter the x value:");
System.out.println("Enter the y value:");
x = s. nextInt();
y = s.nextInt();
max=x;
if(y>max)
{
 max = y;
System.out.println("maxvalue is:"+  max) ;
}
  else{
    System.out.println("maxvalue is:"+  max) ;
  }

}
}
